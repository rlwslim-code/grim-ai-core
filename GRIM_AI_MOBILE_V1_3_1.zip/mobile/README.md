# GRIM native client

Requires Node 20.19+ and Expo Go compatible with Expo SDK 54, or a native development build. No cloud subscription is required to run locally.

```sh
npm install
npx expo install --check
npm run typecheck
npm start
```

Start the FastAPI backend using the root instructions. On a phone, enter the computer's LAN URL such as `http://192.168.1.10:8000` on the sign-in screen. Phone and server must be on the same network, with the backend listening on `0.0.0.0`. Do not use localhost on a physical phone. For a remote server use HTTPS. Android emulator can use `http://10.0.2.2:8000`; iOS Simulator can use localhost.

The first backend account can register through the app; later accounts follow the backend registration policy. Access tokens are kept in Expo SecureStore on native devices, never AsyncStorage. Biometric app locking is optional, requires enrolled device biometrics, and locks when the app leaves the foreground. It is a client privacy lock, not a replacement for backend authentication. Speech output uses installed system voices, with a lower pitch where supported; it is not a custom trained voice. Interrupt stops device speech.

Implemented screens: chat/personality/history, task submission and polled progress, real remote lab controls with unavailable state, memory save/list/delete, settings, logout, emergency stop and resume. Every operation is sent to the authenticated common backend. Chat history is loaded on request. Errors from missing models and unavailable runners are visible.

Native speech recognition, continuous wake-word listening, push notifications, background execution, custom voice models and Siri App Intents are not implemented. Use keyboard dictation for voice input. Expo Go cannot add custom native capabilities. A custom development build registers `grim://live`; create an iOS Shortcut with the **Open URLs** action using that URL. Invoking that Shortcut opens the chat screen; it does not implement App Intents or background wake-word detection. A production App Intent requires a native iOS extension, provisioning, and device testing. Push requires notification credentials and an opted-in token delivery backend. Never put inference API keys in EXPO_PUBLIC variables.

## Verification

TypeScript verification is a static check only. An iPhone/Android device or simulator is required to confirm Expo launch, secure storage, biometrics, audio, keyboard behavior, and connection to your running backend. No mobile binary or store release is included.
