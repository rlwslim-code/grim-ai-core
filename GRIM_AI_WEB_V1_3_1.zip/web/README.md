# GRIM web client

From this directory run `npm ci` then `npm run dev`. Create `.env` from `.env.example` to choose a backend. For a deployed client, set VITE_API_URL to the HTTPS API URL before building. Without this variable, production builds use their own origin, allowing FastAPI to serve the client and API together. Development on port 5173 defaults to localhost:8000.

`npm run build` performs a strict TypeScript check and builds `dist/`. Start FastAPI after building to serve the bundled client at its root URL.

Register with a password of at least 12 characters. Sessions use sessionStorage and remain across refreshes in the current tab. Log out revokes the server session. Text chat requires a configured model provider. The app reports backend/model failures rather than manufacturing responses.

Voice requires a secure context (HTTPS or localhost), microphone permission, and a browser with SpeechRecognition or webkitSpeechRecognition. Speech recognition may use a browser vendor's cloud service. Speech synthesis uses installed browser/OS voices; deep delivery adjusts pitch/rate and does not provide a custom trained voice. Press Activate voice to capture a turn. “Hey GRIM” is recognized only while in-app capture is active, and returns “Rav’kael. I am listening.” Interrupt stops speech output. “Open memory” and other section names navigate by voice. Unrestricted background wake-word detection is not implemented.

Terminal submits tasks to the backend. Save/run uses write_file and python adapters; security analysis writes analysis.py and invokes Bandit. No host terminal or unrestricted command execution is exposed. Lab controls report Docker unavailability honestly. Use the backend's loopback-only defaults and authenticated API; do not expose the development server directly to the public internet.
