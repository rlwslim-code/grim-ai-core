# Persistent one-shot schedules

The API persists one-shot task schedules in SQLite and dispatches them while the single backend process is running. It does not provision a cloud scheduler or wake a powered-off computer.

Use an authenticated `POST /api/schedules` request:

```json
{
  "command": "Inspect managed workspace files",
  "run_at": "2027-01-01T12:00:00Z",
  "steps": [{"tool": "list_files", "args": {}}]
}
```

`run_at` must include a timezone. Supply explicit structured steps; scheduled commands are not interpreted through unrestricted shell access. Use `GET /api/schedules` to inspect schedule/task IDs and `DELETE /api/schedules/{id}` to cancel a pending schedule. At most 20 pending schedules are allowed per account; the API also applies request limits. Task execution permissions, quotas, tool checks and emergency stop apply at dispatch.

If the service is stopped before a pending schedule's due time, it is dispatched when the service next runs. If the process crashes after claiming a schedule but before recording dispatch, recovery marks it interrupted and requires inspection; GRIM avoids automatically replaying unknown actions. A dispatched task records its own status/events. Recurring schedules, cross-process worker coordination and exactly-once external effects are not implemented. Run only one backend worker for this release.

Emergency stop leaves pending schedules waiting. Resume permits dispatch of due pending schedules. Delete unwanted schedules before resuming if you do not want them to run.
